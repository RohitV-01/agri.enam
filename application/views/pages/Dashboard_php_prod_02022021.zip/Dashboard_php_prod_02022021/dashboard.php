<div class="container-fuild" style="float:left;width:100%;background-color:#e6e6e6;padding:10px 0% 12px 0%;">
	<div class="container"><?php print_r($slider); ?></div>
</div>
<section class="content-section" style="background-color:#fff;padding:20px 0 0 0;float:left;width:100%;">
	<div class="container-fuild" style="padding-left:3%;padding-right:3%;">
<div class="container">		
<div class="row">
<div style="margin-top:-15px;padding:0 6px;"><iframe src="https://agmarknet.gov.in/agnew/namticker.aspx" style="width:100%;height:73px;border:none;"></iframe></div>

<div id="dash-marquee"  style="margin-top:4px;padding:0 16px;margin-bottom: 57px;">
	<p style="background-color: #f5f5f5;padding-top: 10px;padding-bottom: 10px;font-size: 15px;font-weight: bold"><marquee><?php echo $this->lang_file->heading_fetch('dashboard-marquee'); ?></marquee></p>
</div>

<div class="col-sm-3 video-sec wow fadeInLeft" data-wow-delay="0.5s" >
			<div class="sidebar-header-title"><span class="e-text"><?php echo $this->lang_file->heading_fetch('enam');?> <?php echo $this->lang_file->heading_fetch('elearningvideos');?></span></div>
			<div class="row">
			<?php if(isset($videos) && count($videos)>0){?>
				<?php $c = 1; foreach($videos as $video){ ?>
				<div class="col-md-12">
					<div class="row elearn-v-box">
						<div class="col-md-12" style="padding-right:0px;">
<div style="border:1px solid #d6d3d3;float:left;padding:3px;"><?php $v = explode('/embed/',$video['v_url']); ?>
						<div class="rahul_youtube" id="iframe1_v_<?php echo $c;?>" data-id="<?php echo $c;?>" data-v_id="iframe1_v_<?php echo $c;?>" data-v_url="<?php echo $video['v_url']; ?>" style="background:url('https://img.youtube.com/vi/<?php echo $v[1];?>/0.jpg') center no-repeat;cursor:pointer;height:125px;width:229px;background-size:cover;position:relative;">
<h3><?php echo $video['v_title']; ?></h3>
<img style="width:64px;"  data-v_id="iframe_v_<?php echo $c;?>" data-v_url="<?php echo $video['v_url']; ?>" data-pid="<?php echo $c;?>" class="play-img" alt="play" src="<?php echo base_url();?>assest/images/new-theme/icon/play-ico.png" /></div>
<div id="iframe_v_<?php echo $c;?>" style="display:none;"></div></div>
</div>
						<div class="col-md-7" style="padding-left:0px;margin-left:-7px;display:none;">
						<h3><b><?php echo $video['v_title']; ?></b></h3>
						<div class="discrip"><?php echo substr($video['v_content'],0,150); ?></div>
						<p>1025 Views - <?php echo $video['created_at']; ?></p></div>
					</div>
				</div>
				<?php $c++; } ?>
			<?php } else{ ?>
					No Videos.
			<?php } ?>
			</div>
		</div>
<div class="about-sec col-lg-5 col-sm-5 wow fadeInUp" data-wow-delay="0.5s">
<div class="sidebar-header-title"><span class="e-text"><?php echo $this->lang_file->heading_fetch('enam_overview'); ?></span></div>
<?php print_r($home_body[0]['content']); ?>
</div>
		
		<div style="display:none;" class="col-lg-3 col-sm-3 wow fadeInUp events-box" data-wow-delay="0.5s" >
			<div style="width:110%;" class="sidebar-header-title"><span class="e-text"><?php echo $this->lang->line('enam');?> <?php echo $this->lang->line('news&events');?></span></div>
			<?php if((count($events) > 0) && (isset($events))){ ?>
				<?php $c=1; foreach($events as $event){ 
					if($c < 3){
					$event_title = strlen($event['title']) > 50 ? substr($event['title'],0,50)."..." : $event['title'];
					?>
					<div class="events-de">
						<div class="register-user-box">
							<b><?php echo $event_title; ?></b>
							<b><?php //echo $event['event_content'];?> </b>
						</div>
						<img style="width:100%;" alt="<?php echo $event['title']; ?>" src="<?php echo base_url(); ?>/Event_gallary/<?php echo $event['event_image']; ?>" />
					</div>
				<?php $c++; } } ?>
			<?php } else { ?>
				<div class="well text-danger">No Events Found.</div>
			<?php }?>
		</div>
		
		<div class="col-lg-3 col-sm-3 home-n home-s-map wow fadeInRight" data-wow-delay="0.5s">
                       
			<div class="focus-section">
<div class="sidebar-header-title"><span><?php echo $this->lang_file->heading_fetch('enam_coverage'); ?></span></div>

<div class="home-ind-map">
<a href="javascript:void(0);"><img alt="India" style="width:100%;" src="<?php echo base_url();?>/assest/images/new-theme/map.jpg" usemap="#image-map" class="state_district" /></a>

<!--<map name="image-map">
    <area data-sate_id="276" class="state_district" alt="ANDHRA PRADESH" title="ANDHRA PRADESH" coords="153,146,143,149,135,149,129,155,122,159,114,164,107,168,101,172,94,173,89,176,88,189,94,190,101,194,106,197,112,195,117,188,114,180,119,172,125,169,131,164,137,158,145,155" shape="poly" />
    <area data-sate_id="100" class="state_district" alt="CHHATTISGARH" title="CHHATTISGARH" coords="124,155,129,150,130,144,127,138,135,130,140,126,143,120,144,110,138,107,128,107,129,114,125,118,120,121,118,129,117,138,118,144,116,150" shape="poly" />
    <area data-sate_id="22" class="state_district" alt="GUJARAT" title="GUJARAT" coords="58,119,59,129,61,136,66,132,70,124,72,116,66,110,61,101,50,98,43,101,34,102,27,106,30,111,39,115,31,119,33,125,40,130,50,131" shape="poly" />
    <area data-sate_id="32" class="state_district" alt="HARYANA" title="HARYANA" coords="72,60,83,61,89,54,91,48,95,57,92,63,92,69,95,75,89,79,83,73,77,66" shape="poly" />
    <area data-sate_id="43" class="state_district" alt="HIMACHAL PRADESH" title="HIMACHAL PRADESH" coords="96,54,90,47,82,41,90,32,96,34,103,36,104,43,105,49" shape="poly">
    <area data-sate_id="47" class="state_district" alt="JHARKHAND" title="JHARKHAND" coords="143,104,152,102,159,100,167,96,173,95,169,104,164,110,157,112,162,117,158,121,151,121,143,119,142,112,138,108,139,100" shape="poly" />
    <area data-sate_id="20" class="state_district" alt="MADHYA PRADESH" title="MADHYA PRADESH" coords="117,126,107,124,98,127,86,127,74,124,68,114,74,109,74,100,79,96,82,102,88,103,92,97,88,91,93,86,101,83,106,90,99,102,109,98,118,97,124,97,132,100,125,114,124,120" shape="poly" />
    <area data-sate_id="296" class="state_district" alt="MAHARASHTRA" title="MAHARASHTRA" coords="96,153,101,145,105,141,110,145,115,150,116,134,118,127,102,125,89,128,76,126,66,124,64,134,57,133,57,143,61,154,60,163,64,172,70,181,71,165,83,163,90,157" shape="poly" />
    <area data-sate_id="384" class="state_district" alt="ODISHA" title="ODISHA" coords="127,154,127,147,131,138,133,131,138,124,151,121,158,119,169,123,165,129,162,137,153,142,150,147,141,149,133,152" shape="poly" />
    <area data-sate_id="26" data-toggle="modal" data-target="#state_click" alt="RAJASTHAN" title="RAJASTHAN" coords="82,73,88,75,92,80,93,86,87,90,90,99,83,102,76,98,73,105,70,113,64,105,56,100,48,101,44,91,39,84,42,75,51,77,57,68,63,65,65,57,72,62,80,62" shape="poly" />
    <area data-sate_id="28" class="state_district" alt="TELANGANA" title="TELANGANA" coords="112,147,121,157,111,165,103,169,94,171,94,159,93,150,102,141" shape="poly" />
    <area data-sate_id="46" class="state_district" alt="UTTAR PRADESH" title="UTTAR PRADESH" coords="91,55,94,65,93,73,94,80,99,83,107,88,102,96,108,96,114,98,120,96,125,99,133,107,141,106,142,95,146,91,143,82,129,76,120,71,109,66,101,62" shape="poly" />
    <area data-sate_id="385" class="state_district" alt="UTTARAKHAND" title="UTTARAKHAND" coords="114,67,102,63,96,56,100,50,105,47,113,52,120,56,116,61" shape="poly" />
    <area data-sate_id="569" class="state_district" alt="WEST BENGAL" title="WEST BENGAL" coords="180,120,173,123,164,119,157,112,165,106,170,98,173,91,176,104,179,112" shape="poly" />
    <area data-sate_id="602" class="state_district" alt="PANJAB" title="PANJAB" coords="82,39,84,46,89,55,80,59,72,58,69,53,75,46" shape="poly" />
    <area data-sate_id="509" class="state_district" alt="TAMIL NADU" title="TAMIL NADU" coords="102,196,96,198,91,202,84,207,88,214,89,220,87,228,90,235,97,234,104,228,109,219,112,210,115,201,114,190" shape="poly">
    <area target="" class="state_district" alt="" title="" href="" coords="" shape="0" />
</map>-->
	
</div>			

</div>
		</div>
	</div></div></div>
</section>



<style type="text/css">
#myModalbankdetail a.close{color:#f00;opacity:1;}
#myModalbankdetail h3{color:#f00;}
@media (max-width:1600px){
#myModalbankdetail{width: 550px; height: 420px;}
}
@media (max-width:1400px){
#myModalbankdetail{width: 550px; height: 420px;}
}

@media (max-width:1200px){
#myModalbankdetail{width: 550px; height: 420px;}
}
@media (max-width:960px){
#myModalbankdetail{width: 550px; height: 420px;}
}

@media (max-width:480px){
#myModalbankdetail{width: 300px; height: 310px;}
}
</style>


<!--<style type="text/css">
#myModalbankdetail a.close{color:#f00;opacity:1;}
#myModalbankdetail h3{color:#f00;}
@media (max-width:1600px){
#myModalbankdetail{width: 550px; height: 300px;}
}
@media (max-width:1400px){
#myModalbankdetail{width: 550px; height: 300px;}
}

@media (max-width:1200px){
#myModalbankdetail{width: 550px; height: 300px;}
}
@media (max-width:960px){
#myModalbankdetail{width: 550px; height: 320px;}
}

@media (max-width:480px){
#myModalbankdetail{width: 300px; height: 300px;}
}
</style>-->

<div class="modal fade" id="myModalbankdetail" style="
    background-color: #fff;
    margin:auto;
    left: 0;
    right: 0;
    border-radius: 23px;border:2px solid #7b7a7a;">
  <div class="modal-header text-center">
    <a class="close" data-dismiss="modal">x</a>
     <h3><b><?php echo $this->lang_file->heading_fetch('bank_modal_heading');?></b></h3> 
  </div>
	<div class="modal-body">

<!-- <p><?php //echo $this->lang_file->heading_fetch('bank_modalbody_2');?></p>
-->
<!-- <img src="<?php //echo base_url();?>Slider_gallary/kisanrath.jpg" alt="img1" style="width: 100%;font-size: 20px"> -->
<h4 style="color: green"><b>Budget speech 2021 announcement: (page # 20, point 107)</b></h4>

<p><i>"The Agriculture Infrastructure Fund would be made available to APMCs for augmenting their infrastructurefacilities"</i></p>
<p><b>Refer :</b></p>
<p><a target="_blank" href="https://www.indiabudget.gov.in/budgetspeech.php">https://www.indiabudget.gov.in/budgetspeech.php</a></p>
<br>
<h4 style="color: green"><b>Operational Guidelines of Agriculture Infrastructure Fund (AIF)</b></h4>
<p><b>Refer :</b></p>
<p><a target="_blank" href="https://pmkisan.gov.in/Documents/Operational%20Guidelines%20of%20Financing%20Facility%20under%20Agriculture%20Infrastructure%20Fund.pdf">https://pmkisan.gov.in/Documents/Operational%20Guidelines%20of%20<br>Financing%20Facility%20under%20Agriculture%20Infrastructure%20Fund.pdf</a></p>


  </div>
</div>
</div>
<script type="text/javascript">
$(window).on('load',function(){
	$('#myModalbankdetail').modal('show');
});
</script>
